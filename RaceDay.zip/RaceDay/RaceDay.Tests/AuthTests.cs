using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;
using static RaceDay.Tests.TestHelpers;

namespace RaceDay.Tests;

public class AuthTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    private HttpClient Client => factory.CreateClient();

    [Theory]
    [InlineData("Organiser")]
    [InlineData("Participant")]
    public async Task Register_WithValidDetails_Returns201_AndNoPassword(string role)
    {
        var res = await Client.PostAsJsonAsync("/api/auth/register",
            new { fullName = "Jane Doe", email = UniqueEmail(), password = Password, role });

        Assert.Equal(HttpStatusCode.Created, res.StatusCode);
        var body = await res.Content.ReadAsStringAsync();
        Assert.Contains(role, body);
        Assert.DoesNotContain("password", body, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Register_DuplicateEmail_Returns409()
    {
        var email = UniqueEmail();
        var payload = new { fullName = "A", email, password = Password, role = "Participant" };
        Assert.Equal(HttpStatusCode.Created, (await Client.PostAsJsonAsync("/api/auth/register", payload)).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, (await Client.PostAsJsonAsync("/api/auth/register", payload)).StatusCode);
    }

    [Fact]
    public async Task Register_AsAdmin_Returns400()
    {
        var res = await Client.PostAsJsonAsync("/api/auth/register",
            new { fullName = "Sneaky", email = UniqueEmail(), password = Password, role = "Admin" });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task Register_ShortPasswordOrBadEmail_Returns400()
    {
        var shortPwd = await Client.PostAsJsonAsync("/api/auth/register",
            new { fullName = "A", email = UniqueEmail(), password = "123", role = "Participant" });
        var badEmail = await Client.PostAsJsonAsync("/api/auth/register",
            new { fullName = "A", email = "not-an-email", password = Password, role = "Participant" });
        Assert.Equal(HttpStatusCode.BadRequest, shortPwd.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, badEmail.StatusCode);
    }

    [Fact]
    public async Task Login_WithValidCredentials_ReturnsTokenAndUser()
    {
        var email = UniqueEmail();
        await Client.PostAsJsonAsync("/api/auth/register", new { fullName = "A", email, password = Password, role = "Organiser" });

        var res = await Client.PostAsJsonAsync("/api/auth/login", new { email, password = Password });

        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var auth = await res.Content.ReadFromJsonAsync<AuthResponseDto>();
        Assert.False(string.IsNullOrWhiteSpace(auth!.Token));
        Assert.Equal("Organiser", auth.User.Role);
    }

    [Fact]
    public async Task Login_WithWrongPassword_Returns401()
    {
        var email = UniqueEmail();
        await Client.PostAsJsonAsync("/api/auth/register", new { fullName = "A", email, password = Password, role = "Participant" });
        var res = await Client.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword1" });
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task Login_UnknownUser_Returns401()
    {
        var res = await Client.PostAsJsonAsync("/api/auth/login", new { email = UniqueEmail(), password = Password });
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Theory]
    [InlineData("/api/users/me")]
    [InlineData("/api/users/me/enrolments")]
    [InlineData("/api/users/me/history")]
    public async Task ProtectedEndpoints_WithoutToken_Return401(string url)
    {
        Assert.Equal(HttpStatusCode.Unauthorized, (await Client.GetAsync(url)).StatusCode);
    }

    [Fact]
    public async Task Profile_CanBeViewedAndUpdated_ByLoggedInUser()
    {
        var (client, _) = await CreateUserAsync(factory, "Participant");

        var put = await client.PutAsJsonAsync("/api/users/me", new { fullName = "New Name", phoneNumber = "0711111111" });
        Assert.Equal(HttpStatusCode.OK, put.StatusCode);

        var me = await client.GetFromJsonAsync<UserDto>("/api/users/me");
        Assert.Equal("New Name", me!.FullName);
    }
}
