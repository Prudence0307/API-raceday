using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;
using static RaceDay.Tests.TestHelpers;

namespace RaceDay.Tests;

public class EnrolmentAndResultTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    private async Task<(HttpClient Org, EventSummaryDto Ev, CategoryDto Cat)> SetupAsync(int max = 100)
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var ev = await CreateEventAsync(org);
        var cat = await CreateCategoryAsync(org, ev.EventID, max);
        return (org, ev, cat);
    }

    [Fact]
    public async Task Participant_CanEnrol_AndEnrolmentIsRecorded()
    {
        var (org, ev, cat) = await SetupAsync();
        var (par, user) = await CreateUserAsync(factory, "Participant");

        var res = await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null);
        Assert.Equal(HttpStatusCode.Created, res.StatusCode);

        var mine = await par.GetFromJsonAsync<List<EnrolmentDto>>("/api/users/me/enrolments");
        var recorded = Assert.Single(mine!);
        Assert.Equal(cat.CategoryID, recorded.CategoryID);
        Assert.Equal(ev.EventID, recorded.EventID);
        Assert.Equal(user.UserID, recorded.ParticipantID);

        var forOrganiser = await org.GetFromJsonAsync<List<EnrolmentDto>>($"/api/events/{ev.EventID}/enrolments");
        Assert.Contains(forOrganiser!, e => e.ParticipantID == user.UserID);
    }

    [Fact]
    public async Task Enrol_Twice_Returns409()
    {
        var (_, _, cat) = await SetupAsync();
        var (par, _) = await CreateUserAsync(factory, "Participant");
        await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null);
        Assert.Equal(HttpStatusCode.Conflict, (await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null)).StatusCode);
    }

    [Fact]
    public async Task Enrol_WhenCategoryFull_Returns409()
    {
        var (_, _, cat) = await SetupAsync(max: 1);
        var (p1, _) = await CreateUserAsync(factory, "Participant");
        var (p2, _) = await CreateUserAsync(factory, "Participant");
        Assert.Equal(HttpStatusCode.Created, (await p1.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null)).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, (await p2.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null)).StatusCode);
    }

    [Fact]
    public async Task Enrol_UnknownCategory_Returns404()
    {
        var (par, _) = await CreateUserAsync(factory, "Participant");
        Assert.Equal(HttpStatusCode.NotFound, (await par.PostAsync("/api/categories/999999/enrolments", null)).StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnrol_Returns403()
    {
        var (org, _, cat) = await SetupAsync();
        Assert.Equal(HttpStatusCode.Forbidden, (await org.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null)).StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotEnrol_Returns401()
    {
        var (_, _, cat) = await SetupAsync();
        Assert.Equal(HttpStatusCode.Unauthorized,
            (await factory.CreateClient().PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null)).StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolments_Returns403()
    {
        var (_, ev, _) = await SetupAsync();
        var (par, _) = await CreateUserAsync(factory, "Participant");
        Assert.Equal(HttpStatusCode.Forbidden, (await par.GetAsync($"/api/events/{ev.EventID}/enrolments")).StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotViewMyEnrolmentsOrHistory_Returns403()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        Assert.Equal(HttpStatusCode.Forbidden, (await org.GetAsync("/api/users/me/enrolments")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await org.GetAsync("/api/users/me/history")).StatusCode);
    }

    [Fact]
    public async Task Participant_CanCancelOwnEnrolment_ButNotSomeoneElses()
    {
        var (_, _, cat) = await SetupAsync();
        var (owner, _) = await CreateUserAsync(factory, "Participant");
        var (other, _) = await CreateUserAsync(factory, "Participant");
        var enrolment = await (await owner.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null))
            .Content.ReadFromJsonAsync<EnrolmentDto>();

        Assert.Equal(HttpStatusCode.Forbidden, (await other.DeleteAsync($"/api/enrolments/{enrolment!.EnrolmentID}")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await owner.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentID}")).StatusCode);
    }

    // ---------------- Results ----------------

    [Fact]
    public async Task Organiser_CanCaptureResult_AndParticipantSeesItInHistory()
    {
        var (org, _, cat) = await SetupAsync();
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var enrolment = await (await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null))
            .Content.ReadFromJsonAsync<EnrolmentDto>();

        var res = await org.PostAsJsonAsync($"/api/enrolments/{enrolment!.EnrolmentID}/results",
            new { finishTime = "00:52:30", position = 3, status = "Finished" });
        Assert.Equal(HttpStatusCode.Created, res.StatusCode);

        var history = await par.GetFromJsonAsync<List<ResultDto>>("/api/users/me/history");
        var mine = Assert.Single(history!);
        Assert.Equal(3, mine.Position);
        Assert.Equal(new TimeSpan(0, 52, 30), mine.FinishTime);

        var board = await factory.CreateClient().GetFromJsonAsync<List<ResultDto>>($"/api/categories/{cat.CategoryID}/results");
        Assert.Single(board!);
    }

    [Fact]
    public async Task CaptureResult_Twice_Returns409()
    {
        var (org, _, cat) = await SetupAsync();
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var enrolment = await (await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null))
            .Content.ReadFromJsonAsync<EnrolmentDto>();
        var body = new { finishTime = "00:50:00", position = 1, status = "Finished" };

        await org.PostAsJsonAsync($"/api/enrolments/{enrolment!.EnrolmentID}/results", body);
        Assert.Equal(HttpStatusCode.Conflict, (await org.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentID}/results", body)).StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCaptureResult_Returns403()
    {
        var (_, _, cat) = await SetupAsync();
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var enrolment = await (await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null))
            .Content.ReadFromJsonAsync<EnrolmentDto>();

        var res = await par.PostAsJsonAsync($"/api/enrolments/{enrolment!.EnrolmentID}/results",
            new { finishTime = "00:40:00", position = 1, status = "Finished" });
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task OtherOrganiser_CannotCaptureResult_Returns403()
    {
        var (_, _, cat) = await SetupAsync();
        var (stranger, _) = await CreateUserAsync(factory, "Organiser");
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var enrolment = await (await par.PostAsync($"/api/categories/{cat.CategoryID}/enrolments", null))
            .Content.ReadFromJsonAsync<EnrolmentDto>();

        var res = await stranger.PostAsJsonAsync($"/api/enrolments/{enrolment!.EnrolmentID}/results",
            new { finishTime = "00:40:00", position = 1, status = "Finished" });
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_UnknownEnrolment_Returns404()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var res = await org.PostAsJsonAsync("/api/enrolments/999999/results", new { finishTime = "00:40:00", position = 1, status = "Finished" });
        Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
    }
}
