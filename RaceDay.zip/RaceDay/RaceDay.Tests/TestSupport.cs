using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Boots the real API in memory, swapping SQL Server for an isolated EF in-memory database.</summary>
public class ApiFactory : WebApplicationFactory<Program>
{
    private readonly string _dbName = Guid.NewGuid().ToString();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureServices(services =>
        {
            var descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<RaceDayDbContext>));
            if (descriptor != null) services.Remove(descriptor);
            services.AddDbContext<RaceDayDbContext>(o => o.UseInMemoryDatabase(_dbName));
        });
    }
}

public static class TestHelpers
{
    public const string Password = "Passw0rd!";

    public static string UniqueEmail() => $"{Guid.NewGuid():N}@test.com";

    /// <summary>Registers + logs in a new user and returns an HttpClient carrying their bearer token.</summary>
    public static async Task<(HttpClient Client, UserDto User)> CreateUserAsync(ApiFactory f, string role)
    {
        var anon = f.CreateClient();
        var email = UniqueEmail();
        var reg = await anon.PostAsJsonAsync("/api/auth/register",
            new { fullName = $"Test {role}", email, password = Password, role, phoneNumber = "0800000000" });
        reg.EnsureSuccessStatusCode();

        var login = await anon.PostAsJsonAsync("/api/auth/login", new { email, password = Password });
        login.EnsureSuccessStatusCode();
        var auth = (await login.Content.ReadFromJsonAsync<AuthResponseDto>())!;

        var client = f.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", auth.Token);
        return (client, auth.User);
    }

    public static object EventBody(string name = "Test Run", int daysAhead = 30, string type = "Running") =>
        new { eventName = name, eventDate = DateTime.Today.AddDays(daysAhead), location = "Polokwane, Limpopo", description = "Test event", eventType = type };

    public static async Task<EventSummaryDto> CreateEventAsync(HttpClient organiser, int daysAhead = 30)
    {
        var res = await organiser.PostAsJsonAsync("/api/events", EventBody(daysAhead: daysAhead));
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<EventSummaryDto>())!;
    }

    public static async Task<CategoryDto> CreateCategoryAsync(HttpClient organiser, int eventId, int max = 100)
    {
        var res = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories",
            new { categoryName = "10km", distance = 10, entryFee = 150, maxParticipants = max });
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<CategoryDto>())!;
    }
}
