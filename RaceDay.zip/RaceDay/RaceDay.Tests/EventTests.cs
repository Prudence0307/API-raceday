using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;
using static RaceDay.Tests.TestHelpers;

namespace RaceDay.Tests;

public class EventTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    [Fact]
    public async Task Organiser_CanCreateEvent_Returns201()
    {
        var (org, user) = await CreateUserAsync(factory, "Organiser");
        var res = await org.PostAsJsonAsync("/api/events", EventBody("Peace Run"));

        Assert.Equal(HttpStatusCode.Created, res.StatusCode);
        var ev = await res.Content.ReadFromJsonAsync<EventSummaryDto>();
        Assert.Equal("Peace Run", ev!.EventName);
        Assert.Equal(user.UserID, ev.OrganiserID);
    }

    [Fact]
    public async Task CreateEvent_WithInvalidType_Returns400()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var res = await org.PostAsJsonAsync("/api/events", EventBody(type: "Swimming"));
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCreateEvent_Returns403()
    {
        var (par, _) = await CreateUserAsync(factory, "Participant");
        Assert.Equal(HttpStatusCode.Forbidden, (await par.PostAsJsonAsync("/api/events", EventBody())).StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotCreateEvent_Returns401()
    {
        var res = await factory.CreateClient().PostAsJsonAsync("/api/events", EventBody());
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task Events_CanBeViewedPublicly_AndFilteredByType()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        await org.PostAsJsonAsync("/api/events", EventBody("Cycle Day", type: "Cycling"));

        var list = await factory.CreateClient().GetFromJsonAsync<List<EventSummaryDto>>("/api/events?type=Cycling");
        Assert.Contains(list!, e => e.EventName == "Cycle Day");
        Assert.All(list!, e => Assert.Equal("Cycling", e.EventType));
    }

    [Fact]
    public async Task GetEvent_Unknown_Returns404()
    {
        Assert.Equal(HttpStatusCode.NotFound, (await factory.CreateClient().GetAsync("/api/events/999999")).StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var ev = await CreateEventAsync(org);

        var res = await org.PutAsJsonAsync($"/api/events/{ev.EventID}", EventBody("Renamed"));

        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        Assert.Equal("Renamed", (await res.Content.ReadFromJsonAsync<EventSummaryDto>())!.EventName);
    }

    [Fact]
    public async Task Organiser_CannotUpdateOrDeleteAnotherOrganisersEvent_Returns403()
    {
        var (owner, _) = await CreateUserAsync(factory, "Organiser");
        var (other, _) = await CreateUserAsync(factory, "Organiser");
        var ev = await CreateEventAsync(owner);

        Assert.Equal(HttpStatusCode.Forbidden, (await other.PutAsJsonAsync($"/api/events/{ev.EventID}", EventBody("Hacked"))).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await other.DeleteAsync($"/api/events/{ev.EventID}")).StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateOrDeleteEvent_Returns403()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var ev = await CreateEventAsync(org);

        Assert.Equal(HttpStatusCode.Forbidden, (await par.PutAsJsonAsync($"/api/events/{ev.EventID}", EventBody())).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await par.DeleteAsync($"/api/events/{ev.EventID}")).StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent_ThenItIsGone()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var ev = await CreateEventAsync(org);
        await CreateCategoryAsync(org, ev.EventID);

        Assert.Equal(HttpStatusCode.OK, (await org.DeleteAsync($"/api/events/{ev.EventID}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await org.GetAsync($"/api/events/{ev.EventID}")).StatusCode);
    }

    [Fact]
    public async Task UpdateOrDelete_UnknownEvent_Returns404()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        Assert.Equal(HttpStatusCode.NotFound, (await org.PutAsJsonAsync("/api/events/999999", EventBody())).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await org.DeleteAsync("/api/events/999999")).StatusCode);
    }

    [Fact]
    public async Task Organiser_CanAddCategory_ButParticipantCannot()
    {
        var (org, _) = await CreateUserAsync(factory, "Organiser");
        var (par, _) = await CreateUserAsync(factory, "Participant");
        var ev = await CreateEventAsync(org);
        var body = new { categoryName = "5km", distance = 5, entryFee = 100, maxParticipants = 50 };

        Assert.Equal(HttpStatusCode.Created, (await org.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", body)).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await par.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", body)).StatusCode);

        var cats = await par.GetFromJsonAsync<List<CategoryDto>>($"/api/events/{ev.EventID}/categories");
        Assert.Single(cats!);
    }
}
