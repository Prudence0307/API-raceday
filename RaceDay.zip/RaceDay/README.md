# RaceDay API (Part 2)

ASP.NET Core 8 Web API · EF Core (Code-First) · SQL Server · JWT auth · Swagger · xUnit

## Setup in Visual Studio 2022
1. Open `RaceDay.sln` (needs the **ASP.NET and web development** workload and the .NET 8 SDK).
2. Edit the connection string in `RaceDay.Api/appsettings.json` if you are not using LocalDB
   (e.g. `Server=localhost;Database=RaceDayDB;Trusted_Connection=True;TrustServerCertificate=True;`).
3. Create the database from the entities (Tools > NuGet Package Manager > Package Manager Console,
   Default project = `RaceDay.Api`):
   ```
   Add-Migration InitialCreate
   Update-Database
   ```
   (In Development the app also runs `Migrate()` automatically on startup.)
4. Set `RaceDay.Api` as the startup project and press F5. Swagger opens at `/swagger`.
5. Run the tests: Test > Run All Tests (Test Explorer). They use an in-memory database, not SQL Server.

## Using Swagger
POST `/api/auth/register`, then POST `/api/auth/login`, copy the token, click **Authorize**, paste it.

## Notes
- Roles: users choose Organiser or Participant at registration; Admin cannot be self-registered.
- Passwords are hashed with BCrypt. The role is stored in the JWT, and `[Authorize(Roles = ...)]` enforces access.
- Change `Jwt:Key` before deploying (use user-secrets or an environment variable).
