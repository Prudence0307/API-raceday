using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public class RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<RaceRoute> Routes => Set<RaceRoute>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    // The SQL script uses VARCHAR (not NVARCHAR)
    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
        => configurationBuilder.Properties<string>().AreUnicode(false);

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>(e =>
        {
            e.ToTable("Users", t => t.HasCheckConstraint("CK_Users_Role", "[Role] IN ('Organiser','Participant','Admin')"));
            e.HasIndex(x => x.Email).IsUnique().HasDatabaseName("UQ_Users_Email");
        });

        b.Entity<Event>(e =>
        {
            e.ToTable("Events", t => t.HasCheckConstraint("CK_Events_Type", "[EventType] IN ('Running','Walking','Cycling')"));
            e.HasOne(x => x.Organiser).WithMany(u => u.OrganisedEvents)
                .HasForeignKey(x => x.OrganiserID).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<Category>(e =>
        {
            e.ToTable("Categories");
            e.HasOne(x => x.Event).WithMany(ev => ev.Categories)
                .HasForeignKey(x => x.EventID).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<RaceRoute>(e =>
        {
            e.ToTable("Routes");
            e.HasKey(x => x.RouteID);
            e.HasOne(x => x.Category).WithOne(c => c.Route)
                .HasForeignKey<RaceRoute>(x => x.CategoryID).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => x.CategoryID).IsUnique().HasDatabaseName("UQ_Routes_Category");
        });

        b.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolments", t => t.HasCheckConstraint("CK_Enrolments_Status", "[Status] IN ('Pending','Confirmed','Cancelled')"));
            e.HasOne(x => x.Participant).WithMany(u => u.Enrolments)
                .HasForeignKey(x => x.ParticipantID).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Category).WithMany(c => c.Enrolments)
                .HasForeignKey(x => x.CategoryID).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new { x.ParticipantID, x.CategoryID }).IsUnique()
                .HasDatabaseName("UQ_Enrolments_Participant_Category");
        });

        b.Entity<Result>(e =>
        {
            e.ToTable("Results", t => t.HasCheckConstraint("CK_Results_Status", "[Status] IN ('Finished','DNF','DSQ')"));
            e.HasOne(x => x.Enrolment).WithOne(en => en.Result)
                .HasForeignKey<Result>(x => x.EnrolmentID).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => x.EnrolmentID).IsUnique().HasDatabaseName("UQ_Results_Enrolment");
        });
    }
}

public static class DbExtensions
{
    public static IQueryable<Enrolment> WithDetails(this IQueryable<Enrolment> q) =>
        q.Include(e => e.Participant).Include(e => e.Category).ThenInclude(c => c.Event);

    public static IQueryable<Result> WithDetails(this IQueryable<Result> q) =>
        q.Include(r => r.Enrolment).ThenInclude(e => e.Participant)
         .Include(r => r.Enrolment).ThenInclude(e => e.Category).ThenInclude(c => c.Event);

    /// <summary>Queues deletion of categories plus their routes, enrolments and results (FKs are NO ACTION). Caller must SaveChanges.</summary>
    public static async Task RemoveCategoriesCascadeAsync(this RaceDayDbContext db, List<int> categoryIds)
    {
        var enrolments = await db.Enrolments.Where(e => categoryIds.Contains(e.CategoryID)).ToListAsync();
        var enrolmentIds = enrolments.Select(e => e.EnrolmentID).ToList();
        db.Results.RemoveRange(await db.Results.Where(r => enrolmentIds.Contains(r.EnrolmentID)).ToListAsync());
        db.Enrolments.RemoveRange(enrolments);
        db.Routes.RemoveRange(await db.Routes.Where(r => categoryIds.Contains(r.CategoryID)).ToListAsync());
        db.Categories.RemoveRange(await db.Categories.Where(c => categoryIds.Contains(c.CategoryID)).ToListAsync());
    }
}
