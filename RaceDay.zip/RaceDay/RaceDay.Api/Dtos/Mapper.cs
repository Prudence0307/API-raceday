using RaceDay.Api.Models;

namespace RaceDay.Api.Dtos;

public static class Mapper
{
    public static UserDto ToDto(this User u) =>
        new(u.UserID, u.FullName, u.Email, u.Role, u.PhoneNumber, u.DateRegistered);

    public static RouteDto ToDto(this RaceRoute r) =>
        new(r.RouteID, r.CategoryID, r.RouteName, r.StartPoint, r.EndPoint, r.ElevationGain, r.MapURL);

    public static CategoryDto ToDto(this Category c) =>
        new(c.CategoryID, c.EventID, c.CategoryName, c.Distance, c.EntryFee, c.MaxParticipants, c.Route?.ToDto());

    public static EventSummaryDto ToSummary(this Event e) =>
        new(e.EventID, e.OrganiserID, e.EventName, e.EventDate, e.Location, e.Description, e.EventType);

    public static EventDetailDto ToDetail(this Event e) =>
        new(e.EventID, e.OrganiserID, e.EventName, e.EventDate, e.Location, e.Description, e.EventType,
            e.Categories.OrderBy(c => c.Distance).Select(c => c.ToDto()).ToList());

    /// <summary>Requires Participant and Category.Event to be loaded.</summary>
    public static EnrolmentDto ToDto(this Enrolment e) =>
        new(e.EnrolmentID, e.ParticipantID, e.Participant.FullName, e.CategoryID, e.Category.CategoryName,
            e.Category.EventID, e.Category.Event.EventName, e.Category.Event.EventDate, e.EnrolmentDate, e.Status);

    /// <summary>Requires Enrolment.Participant and Enrolment.Category.Event to be loaded.</summary>
    public static ResultDto ToDto(this Result r)
    {
        var en = r.Enrolment;
        return new(r.ResultID, r.EnrolmentID, en.ParticipantID, en.Participant.FullName, en.CategoryID,
            en.Category.CategoryName, en.Category.EventID, en.Category.Event.EventName, en.Category.Event.EventDate,
            r.FinishTime, r.Position, r.Status);
    }
}
