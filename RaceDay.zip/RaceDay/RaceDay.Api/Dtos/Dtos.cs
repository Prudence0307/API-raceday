using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

// ---------- Requests ----------
public class RegisterDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress, StringLength(150)] public string Email { get; set; } = "";
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = "";
    /// <summary>"Organiser" or "Participant". Admin cannot be self-registered.</summary>
    [Required] public string Role { get; set; } = "";
    [StringLength(20)] public string? PhoneNumber { get; set; }
}

public class LoginDto
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required] public string Password { get; set; } = "";
}

public class UpdateProfileDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [StringLength(20)] public string? PhoneNumber { get; set; }
}

public class EventUpsertDto
{
    [Required, StringLength(150)] public string EventName { get; set; } = "";
    [Required] public DateTime EventDate { get; set; }
    [Required, StringLength(150)] public string Location { get; set; } = "";
    public string? Description { get; set; }
    /// <summary>Running, Walking or Cycling.</summary>
    [Required, RegularExpression("^(Running|Walking|Cycling)$", ErrorMessage = "EventType must be Running, Walking or Cycling.")]
    public string EventType { get; set; } = "Running";
}

public class CategoryUpsertDto
{
    [Required, StringLength(50)] public string CategoryName { get; set; } = "";
    [Range(0.01, 999.99)] public decimal Distance { get; set; }
    [Range(0, 999999.99)] public decimal EntryFee { get; set; }
    [Range(1, int.MaxValue)] public int MaxParticipants { get; set; } = 500;
}

public class RouteUpsertDto
{
    [StringLength(100)] public string? RouteName { get; set; }
    [Required, StringLength(150)] public string StartPoint { get; set; } = "";
    [Required, StringLength(150)] public string EndPoint { get; set; } = "";
    [Range(0, 100000)] public int? ElevationGain { get; set; }
    [StringLength(255)] public string? MapUrl { get; set; }
}

public class ResultUpsertDto
{
    /// <summary>Finish time as hh:mm:ss (required when Status is Finished).</summary>
    public TimeSpan? FinishTime { get; set; }
    [Range(1, int.MaxValue)] public int? Position { get; set; }
    /// <summary>Finished, DNF or DSQ.</summary>
    [Required, RegularExpression("^(Finished|DNF|DSQ)$", ErrorMessage = "Status must be Finished, DNF or DSQ.")]
    public string Status { get; set; } = "Finished";
}

// ---------- Responses ----------
public record ApiError(string Message);
public record UserDto(int UserID, string FullName, string Email, string Role, string? PhoneNumber, DateTime DateRegistered);
public record AuthResponseDto(string Token, UserDto User);
public record RouteDto(int RouteID, int CategoryID, string? RouteName, string StartPoint, string EndPoint, int? ElevationGain, string? MapUrl);
public record CategoryDto(int CategoryID, int EventID, string CategoryName, decimal Distance, decimal EntryFee, int MaxParticipants, RouteDto? Route);
public record EventSummaryDto(int EventID, int OrganiserID, string EventName, DateTime EventDate, string Location, string? Description, string EventType);
public record EventDetailDto(int EventID, int OrganiserID, string EventName, DateTime EventDate, string Location, string? Description, string EventType, List<CategoryDto> Categories);
public record EnrolmentDto(int EnrolmentID, int ParticipantID, string ParticipantName, int CategoryID, string CategoryName, int EventID, string EventName, DateTime EventDate, DateTime EnrolmentDate, string Status);
public record ResultDto(int ResultID, int EnrolmentID, int ParticipantID, string ParticipantName, int CategoryID, string CategoryName, int EventID, string EventName, DateTime EventDate, TimeSpan? FinishTime, int? Position, string Status);
public record WeatherDayDto(string Date, double? MaxTempC, double? MinTempC, int? RainChancePercent);
public record WeatherDto(string Location, double Latitude, double Longitude, List<WeatherDayDto> Forecast);
