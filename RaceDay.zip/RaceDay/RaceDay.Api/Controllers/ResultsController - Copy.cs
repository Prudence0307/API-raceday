using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api")]
[Authorize(Roles = Roles.Organiser)]
[Produces("application/json")]
public class ResultsController(RaceDayDbContext db) : ControllerBase
{
    /// <summary>Organiser only: captures a result (finish time, position, status) for an enrolment in one of the organiser's events.</summary>
    /// <remarks>status is Finished, DNF or DSQ. finishTime (hh:mm:ss) is required when status is Finished.</remarks>
    /// <response code="201">Result created.</response>
    /// <response code="400">Validation failed, or the enrolment was cancelled.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Enrolment not found.</response>
    /// <response code="409">A result has already been captured for this enrolment.</response>
    [HttpPost("enrolments/{enrolmentId:int}/results")]
    [ProducesResponseType(typeof(ResultDto), 201)]
    [ProducesResponseType(typeof(ApiError), 400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    [ProducesResponseType(typeof(ApiError), 409)]
    public async Task<ActionResult<ResultDto>> Capture(int enrolmentId, ResultUpsertDto dto)
    {
        var enrolment = await db.Enrolments.Include(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentID == enrolmentId);
        if (enrolment == null) return NotFound(new ApiError("Enrolment not found."));
        if (enrolment.Category.Event.OrganiserID != User.GetUserId()) return Forbid();
        if (enrolment.Status == EnrolmentStatus.Cancelled)
            return BadRequest(new ApiError("Cannot capture a result for a cancelled enrolment."));
        if (dto.Status == "Finished" && dto.FinishTime == null)
            return BadRequest(new ApiError("finishTime is required when status is Finished."));
        if (await db.Results.AnyAsync(r => r.EnrolmentID == enrolmentId))
            return Conflict(new ApiError("A result has already been captured for this enrolment."));

        var result = new Result { EnrolmentID = enrolmentId, FinishTime = dto.FinishTime, Position = dto.Position, Status = dto.Status };
        db.Results.Add(result);
        await db.SaveChangesAsync();

        var full = await db.Results.AsNoTracking().WithDetails().FirstAsync(r => r.ResultID == result.ResultID);
        return Created($"/api/categories/{enrolment.CategoryID}/results", full.ToDto());
    }

    /// <summary>Organiser only: updates / corrects a captured result.</summary>
    /// <response code="200">Result updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Result not found.</response>
    [HttpPut("results/{id:int}")]
    [ProducesResponseType(typeof(ResultDto), 200)]
    [ProducesResponseType(typeof(ApiError), 400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<ResultDto>> Update(int id, ResultUpsertDto dto)
    {
        var result = await db.Results.WithDetails().FirstOrDefaultAsync(r => r.ResultID == id);
        if (result == null) return NotFound(new ApiError("Result not found."));
        if (result.Enrolment.Category.Event.OrganiserID != User.GetUserId()) return Forbid();
        if (dto.Status == "Finished" && dto.FinishTime == null)
            return BadRequest(new ApiError("finishTime is required when status is Finished."));

        result.FinishTime = dto.FinishTime; result.Position = dto.Position; result.Status = dto.Status;
        await db.SaveChangesAsync();
        return Ok(result.ToDto());
    }
}
