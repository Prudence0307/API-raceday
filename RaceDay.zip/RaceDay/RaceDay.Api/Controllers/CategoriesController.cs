using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api")]
[Produces("application/json")]
public class CategoriesController(RaceDayDbContext db, IWeatherService weather) : ControllerBase
{
    private static ApiError NotFoundMsg(string what) => new($"{what} not found.");

    // ---------------- Categories ----------------

    /// <summary>Lists all categories (e.g. 5km, 10km, 21km) for an event.</summary>
    /// <response code="200">Array of categories.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("events/{eventId:int}/categories"), AllowAnonymous]
    [ProducesResponseType(typeof(List<CategoryDto>), 200)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<List<CategoryDto>>> GetForEvent(int eventId)
    {
        if (!await db.Events.AnyAsync(e => e.EventID == eventId)) return NotFound(NotFoundMsg("Event"));
        var cats = await db.Categories.AsNoTracking().Include(c => c.Route)
            .Where(c => c.EventID == eventId).OrderBy(c => c.Distance).ToListAsync();
        return Ok(cats.Select(c => c.ToDto()).ToList());
    }

    /// <summary>Organiser only: creates a category under an event the organiser owns.</summary>
    /// <remarks>Expects categoryName, distance, entryFee and maxParticipants.</remarks>
    /// <response code="201">Category created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Event not found.</response>
    [HttpPost("events/{eventId:int}/categories"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryDto), 201)]
    [ProducesResponseType(400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<CategoryDto>> Create(int eventId, CategoryUpsertDto dto)
    {
        var ev = await db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev == null) return NotFound(NotFoundMsg("Event"));
        if (ev.OrganiserID != User.GetUserId()) return Forbid();

        var cat = new Category
        {
            EventID = eventId, CategoryName = dto.CategoryName, Distance = dto.Distance,
            EntryFee = dto.EntryFee, MaxParticipants = dto.MaxParticipants
        };
        db.Categories.Add(cat);
        await db.SaveChangesAsync();
        return Created($"/api/events/{eventId}/categories", cat.ToDto());
    }

    /// <summary>Organiser only: updates a category belonging to one of the organiser's events.</summary>
    /// <response code="200">Category updated.</response>
    /// <response code="403">Not an Organiser, or not the owner.</response>
    /// <response code="404">Category not found.</response>
    [HttpPut("categories/{id:int}"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<CategoryDto>> Update(int id, CategoryUpsertDto dto)
    {
        var cat = await db.Categories.Include(c => c.Event).Include(c => c.Route).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (cat == null) return NotFound(NotFoundMsg("Category"));
        if (cat.Event.OrganiserID != User.GetUserId()) return Forbid();

        cat.CategoryName = dto.CategoryName; cat.Distance = dto.Distance;
        cat.EntryFee = dto.EntryFee; cat.MaxParticipants = dto.MaxParticipants;
        await db.SaveChangesAsync();
        return Ok(cat.ToDto());
    }

    /// <summary>Organiser only: deletes a category (and its route, enrolments and results).</summary>
    /// <response code="200">Confirmation message.</response>
    /// <response code="403">Not an Organiser, or not the owner.</response>
    /// <response code="404">Category not found.</response>
    [HttpDelete("categories/{id:int}"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(ApiError), 200)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<IActionResult> Delete(int id)
    {
        var cat = await db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (cat == null) return NotFound(NotFoundMsg("Category"));
        if (cat.Event.OrganiserID != User.GetUserId()) return Forbid();

        await db.RemoveCategoriesCascadeAsync(new List<int> { id });
        await db.SaveChangesAsync();
        return Ok(new ApiError("Category deleted."));
    }

    // ---------------- Routes ----------------

    /// <summary>Gets the route details (start/end, elevation, map) for a category.</summary>
    /// <response code="200">The route.</response>
    /// <response code="404">Category or route not found.</response>
    [HttpGet("categories/{id:int}/route"), AllowAnonymous]
    [ProducesResponseType(typeof(RouteDto), 200)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<RouteDto>> GetRoute(int id)
    {
        var route = await db.Routes.AsNoTracking().FirstOrDefaultAsync(r => r.CategoryID == id);
        return route == null ? NotFound(NotFoundMsg("Route")) : Ok(route.ToDto());
    }

    /// <summary>Organiser only: adds route information to a category (one route per category).</summary>
    /// <remarks>Expects routeName, startPoint, endPoint, elevationGain and mapUrl.</remarks>
    /// <response code="201">Route created.</response>
    /// <response code="403">Not an Organiser, or not the owner.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">The category already has a route.</response>
    [HttpPost("categories/{id:int}/route"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(RouteDto), 201)]
    [ProducesResponseType(400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    [ProducesResponseType(typeof(ApiError), 409)]
    public async Task<ActionResult<RouteDto>> CreateRoute(int id, RouteUpsertDto dto)
    {
        var cat = await db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (cat == null) return NotFound(NotFoundMsg("Category"));
        if (cat.Event.OrganiserID != User.GetUserId()) return Forbid();
        if (await db.Routes.AnyAsync(r => r.CategoryID == id))
            return Conflict(new ApiError("This category already has a route."));

        var route = new RaceRoute
        {
            CategoryID = id, RouteName = dto.RouteName, StartPoint = dto.StartPoint, EndPoint = dto.EndPoint,
            ElevationGain = dto.ElevationGain ?? 0, MapURL = dto.MapUrl
        };
        db.Routes.Add(route);
        await db.SaveChangesAsync();
        return Created($"/api/categories/{id}/route", route.ToDto());
    }

    /// <summary>Organiser only: updates the route information of a category.</summary>
    /// <response code="200">Route updated.</response>
    /// <response code="403">Not an Organiser, or not the owner.</response>
    /// <response code="404">Category or route not found.</response>
    [HttpPut("categories/{id:int}/route"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(RouteDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<RouteDto>> UpdateRoute(int id, RouteUpsertDto dto)
    {
        var cat = await db.Categories.Include(c => c.Event).Include(c => c.Route).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (cat == null) return NotFound(NotFoundMsg("Category"));
        if (cat.Event.OrganiserID != User.GetUserId()) return Forbid();
        if (cat.Route == null) return NotFound(NotFoundMsg("Route"));

        cat.Route.RouteName = dto.RouteName; cat.Route.StartPoint = dto.StartPoint; cat.Route.EndPoint = dto.EndPoint;
        cat.Route.ElevationGain = dto.ElevationGain ?? 0; cat.Route.MapURL = dto.MapUrl;
        await db.SaveChangesAsync();
        return Ok(cat.Route.ToDto());
    }

    // ---------------- Weather ----------------

    /// <summary>Any logged-in user: 7-day weather forecast for the event location of a category.</summary>
    /// <response code="200">Forecast summary.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">Category not found or no forecast available.</response>
    /// <response code="503">Weather provider unavailable.</response>
    [HttpGet("categories/{id:int}/weather"), Authorize]
    [ProducesResponseType(typeof(WeatherDto), 200)]
    [ProducesResponseType(401)]
    [ProducesResponseType(typeof(ApiError), 404)]
    [ProducesResponseType(typeof(ApiError), 503)]
    public async Task<ActionResult<WeatherDto>> GetWeather(int id, CancellationToken ct)
    {
        var cat = await db.Categories.AsNoTracking().Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id, ct);
        if (cat == null) return NotFound(NotFoundMsg("Category"));
        try
        {
            var w = await weather.GetForecastAsync(cat.Event.Location, ct);
            return w == null ? NotFound(new ApiError("No forecast available for this location.")) : Ok(w);
        }
        catch (HttpRequestException)
        {
            return StatusCode(503, new ApiError("Weather service is currently unavailable."));
        }
    }

    // ---------------- Leaderboard ----------------

    /// <summary>Lists all results for a category (the leaderboard for that distance), ordered by position.</summary>
    /// <response code="200">Array of results.</response>
    /// <response code="404">Category not found.</response>
    [HttpGet("categories/{id:int}/results"), AllowAnonymous]
    [ProducesResponseType(typeof(List<ResultDto>), 200)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<List<ResultDto>>> GetResults(int id)
    {
        if (!await db.Categories.AnyAsync(c => c.CategoryID == id)) return NotFound(NotFoundMsg("Category"));
        var list = await db.Results.AsNoTracking().WithDetails().Where(r => r.Enrolment.CategoryID == id).ToListAsync();
        return Ok(list.OrderBy(r => r.Position == null).ThenBy(r => r.Position).Select(r => r.ToDto()).ToList());
    }
}
