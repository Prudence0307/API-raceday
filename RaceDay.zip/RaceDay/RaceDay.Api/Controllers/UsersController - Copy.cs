using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/users/me")]
[Authorize]
[Produces("application/json")]
public class UsersController(RaceDayDbContext db) : ControllerBase
{
    /// <summary>Gets the logged-in user's own profile.</summary>
    /// <response code="200">The profile.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet]
    [ProducesResponseType(typeof(UserDto), 200)]
    [ProducesResponseType(401)]
    public async Task<ActionResult<UserDto>> GetMe()
    {
        var user = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.UserID == User.GetUserId());
        return user == null ? Unauthorized() : Ok(user.ToDto());
    }

    /// <summary>Updates the logged-in user's own profile (fullName, phoneNumber).</summary>
    /// <response code="200">The updated profile.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPut]
    [ProducesResponseType(typeof(UserDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(401)]
    public async Task<ActionResult<UserDto>> UpdateMe(UpdateProfileDto dto)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.UserID == User.GetUserId());
        if (user == null) return Unauthorized();
        user.FullName = dto.FullName.Trim();
        user.PhoneNumber = dto.PhoneNumber;
        await db.SaveChangesAsync();
        return Ok(user.ToDto());
    }

    /// <summary>Participant only: the logged-in participant's own results (performance history), newest first.</summary>
    /// <response code="200">Array of results.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not a Participant.</response>
    [HttpGet("history"), Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(List<ResultDto>), 200)]
    [ProducesResponseType(401)]
    [ProducesResponseType(403)]
    public async Task<ActionResult<List<ResultDto>>> History()
    {
        var uid = User.GetUserId();
        var results = await db.Results.AsNoTracking().WithDetails()
            .Where(r => r.Enrolment.ParticipantID == uid).ToListAsync();
        return Ok(results.OrderByDescending(r => r.Enrolment.Category.Event.EventDate).Select(r => r.ToDto()).ToList());
    }

    /// <summary>Participant only: the logged-in participant's own enrolments (upcoming and past).</summary>
    /// <response code="200">Array of enrolments.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not a Participant.</response>
    [HttpGet("enrolments"), Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(List<EnrolmentDto>), 200)]
    [ProducesResponseType(401)]
    [ProducesResponseType(403)]
    public async Task<ActionResult<List<EnrolmentDto>>> MyEnrolments()
    {
        var uid = User.GetUserId();
        var list = await db.Enrolments.AsNoTracking().WithDetails().Where(e => e.ParticipantID == uid).ToListAsync();
        return Ok(list.OrderByDescending(e => e.Category.Event.EventDate).Select(e => e.ToDto()).ToList());
    }
}
