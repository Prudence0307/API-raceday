using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/auth")]
[Produces("application/json")]
public class AuthController(RaceDayDbContext db, ITokenService tokens) : ControllerBase
{
    /// <summary>Registers a new account as an Organiser or a Participant.</summary>
    /// <remarks>
    /// Expects fullName, email, password (min 8 chars), role ("Organiser" or "Participant") and optional phoneNumber.
    /// The Admin role cannot be self-selected. The password is hashed with BCrypt and never returned.
    /// </remarks>
    /// <response code="201">User created (password not returned).</response>
    /// <response code="400">Validation failed (e.g. invalid role, weak password, bad email).</response>
    /// <response code="409">Email already registered.</response>
    [HttpPost("register"), AllowAnonymous]
    [ProducesResponseType(typeof(UserDto), 201)]
    [ProducesResponseType(typeof(ApiError), 400)]
    [ProducesResponseType(typeof(ApiError), 409)]
    public async Task<ActionResult<UserDto>> Register(RegisterDto dto)
    {
        if (dto.Role != Roles.Organiser && dto.Role != Roles.Participant)
            return BadRequest(new ApiError("Role must be either 'Organiser' or 'Participant'."));

        var email = dto.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Email == email))
            return Conflict(new ApiError("Email is already registered."));

        var user = new User
        {
            FullName = dto.FullName.Trim(),
            Email = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Role = dto.Role,
            PhoneNumber = dto.PhoneNumber
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return Created("/api/users/me", user.ToDto());
    }

    /// <summary>Logs in and returns a JWT access token plus the user's details.</summary>
    /// <remarks>Send the token as "Authorization: Bearer {token}" on all protected endpoints. The token carries the user's role.</remarks>
    /// <response code="200">Returns { token, user }.</response>
    /// <response code="401">Invalid credentials.</response>
    [HttpPost("login"), AllowAnonymous]
    [ProducesResponseType(typeof(AuthResponseDto), 200)]
    [ProducesResponseType(typeof(ApiError), 401)]
    public async Task<ActionResult<AuthResponseDto>> Login(LoginDto dto)
    {
        var email = dto.Email.Trim().ToLowerInvariant();
        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            return Unauthorized(new ApiError("Invalid email or password."));

        return Ok(new AuthResponseDto(tokens.CreateToken(user), user.ToDto()));
    }
}
