using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api")]
[Produces("application/json")]
public class EnrolmentsController(RaceDayDbContext db) : ControllerBase
{
    /// <summary>Participant only: enrols the logged-in participant into a category.</summary>
    /// <remarks>No body needed - the participant comes from the token. Re-enrolling after a cancellation reactivates the old enrolment.</remarks>
    /// <response code="201">Enrolment created (links participant, category and event).</response>
    /// <response code="400">The event has already taken place.</response>
    /// <response code="403">Not a Participant.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">Already enrolled, or the category is full.</response>
    [HttpPost("categories/{categoryId:int}/enrolments"), Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(EnrolmentDto), 201)]
    [ProducesResponseType(typeof(ApiError), 400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    [ProducesResponseType(typeof(ApiError), 409)]
    public async Task<ActionResult<EnrolmentDto>> Enrol(int categoryId)
    {
        var uid = User.GetUserId();
        var cat = await db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == categoryId);
        if (cat == null) return NotFound(new ApiError("Category not found."));
        if (cat.Event.EventDate.Date < DateTime.Today)
            return BadRequest(new ApiError("This event has already taken place."));

        var existing = await db.Enrolments.FirstOrDefaultAsync(e => e.ParticipantID == uid && e.CategoryID == categoryId);
        if (existing != null && existing.Status != EnrolmentStatus.Cancelled)
            return Conflict(new ApiError("You are already enrolled in this category."));

        var taken = await db.Enrolments.CountAsync(e => e.CategoryID == categoryId && e.Status != EnrolmentStatus.Cancelled);
        if (taken >= cat.MaxParticipants) return Conflict(new ApiError("This category is full."));

        Enrolment enrolment;
        if (existing != null)
        {
            existing.Status = EnrolmentStatus.Confirmed;
            existing.EnrolmentDate = DateTime.Now;
            enrolment = existing;
        }
        else
        {
            enrolment = new Enrolment { ParticipantID = uid, CategoryID = categoryId, Status = EnrolmentStatus.Confirmed };
            db.Enrolments.Add(enrolment);
        }
        await db.SaveChangesAsync();

        var full = await db.Enrolments.AsNoTracking().WithDetails().FirstAsync(e => e.EnrolmentID == enrolment.EnrolmentID);
        return Created("/api/users/me/enrolments", full.ToDto());
    }

    /// <summary>Organiser only: lists all enrolments for the categories of an event the organiser owns.</summary>
    /// <response code="200">Array of enrolments.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("events/{eventId:int}/enrolments"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(List<EnrolmentDto>), 200)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<List<EnrolmentDto>>> ForEvent(int eventId)
    {
        var ev = await db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev == null) return NotFound(new ApiError("Event not found."));
        if (ev.OrganiserID != User.GetUserId()) return Forbid();

        var list = await db.Enrolments.AsNoTracking().WithDetails().Where(e => e.Category.EventID == eventId).ToListAsync();
        return Ok(list.OrderBy(e => e.Category.Distance).ThenBy(e => e.EnrolmentDate).Select(e => e.ToDto()).ToList());
    }

    /// <summary>Participant only: cancels the logged-in participant's own enrolment (status becomes Cancelled).</summary>
    /// <response code="200">Confirmation message.</response>
    /// <response code="403">Not a Participant, or not the owner of this enrolment.</response>
    /// <response code="404">Enrolment not found.</response>
    [HttpDelete("enrolments/{id:int}"), Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(ApiError), 200)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<IActionResult> Cancel(int id)
    {
        var enrolment = await db.Enrolments.FirstOrDefaultAsync(e => e.EnrolmentID == id);
        if (enrolment == null) return NotFound(new ApiError("Enrolment not found."));
        if (enrolment.ParticipantID != User.GetUserId()) return Forbid();

        enrolment.Status = EnrolmentStatus.Cancelled;
        await db.SaveChangesAsync();
        return Ok(new ApiError("Enrolment cancelled."));
    }
}
