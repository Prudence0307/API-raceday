using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/events")]
[Produces("application/json")]
public class EventsController(RaceDayDbContext db) : ControllerBase
{
    /// <summary>Lists upcoming events with optional filters.</summary>
    /// <param name="type">Running, Walking or Cycling.</param>
    /// <param name="location">Text contained in the event location.</param>
    /// <param name="date">Only events on this date.</param>
    /// <param name="includePast">Set true to include events that have already happened.</param>
    /// <response code="200">Array of events ordered by date.</response>
    [HttpGet, AllowAnonymous]
    [ProducesResponseType(typeof(List<EventSummaryDto>), 200)]
    public async Task<ActionResult<List<EventSummaryDto>>> GetEvents(
        [FromQuery] string? type, [FromQuery] string? location, [FromQuery] DateTime? date, [FromQuery] bool includePast = false)
    {
        var q = db.Events.AsNoTracking().AsQueryable();
        if (!includePast) q = q.Where(e => e.EventDate >= DateTime.Today);
        if (!string.IsNullOrWhiteSpace(type)) q = q.Where(e => e.EventType == type);
        if (!string.IsNullOrWhiteSpace(location)) q = q.Where(e => e.Location.Contains(location));
        if (date.HasValue) { var d = date.Value.Date; q = q.Where(e => e.EventDate == d); }
        var list = await q.OrderBy(e => e.EventDate).ToListAsync();
        return Ok(list.Select(e => e.ToSummary()).ToList());
    }

    /// <summary>Gets one event with its categories and route info.</summary>
    /// <response code="200">The event.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("{id:int}"), AllowAnonymous]
    [ProducesResponseType(typeof(EventDetailDto), 200)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<EventDetailDto>> GetById(int id)
    {
        var ev = await db.Events.AsNoTracking().Include(e => e.Categories).ThenInclude(c => c.Route)
            .FirstOrDefaultAsync(e => e.EventID == id);
        return ev == null ? NotFound(new ApiError("Event not found.")) : Ok(ev.ToDetail());
    }

    /// <summary>Organiser only: creates an event owned by the logged-in organiser.</summary>
    /// <remarks>Expects eventName, eventDate, location, description and eventType (Running, Walking or Cycling).</remarks>
    /// <response code="201">Event created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser.</response>
    [HttpPost, Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventSummaryDto), 201)]
    [ProducesResponseType(400)]
    [ProducesResponseType(401)]
    [ProducesResponseType(403)]
    public async Task<ActionResult<EventSummaryDto>> Create(EventUpsertDto dto)
    {
        var ev = new Event
        {
            OrganiserID = User.GetUserId(),
            EventName = dto.EventName, EventDate = dto.EventDate.Date, Location = dto.Location,
            Description = dto.Description, EventType = dto.EventType
        };
        db.Events.Add(ev);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = ev.EventID }, ev.ToSummary());
    }

    /// <summary>Organiser only: updates an event owned by the logged-in organiser.</summary>
    /// <response code="200">Event updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event not found.</response>
    [HttpPut("{id:int}"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventSummaryDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<ActionResult<EventSummaryDto>> Update(int id, EventUpsertDto dto)
    {
        var ev = await db.Events.FirstOrDefaultAsync(e => e.EventID == id);
        if (ev == null) return NotFound(new ApiError("Event not found."));
        if (ev.OrganiserID != User.GetUserId()) return Forbid();

        ev.EventName = dto.EventName; ev.EventDate = dto.EventDate.Date; ev.Location = dto.Location;
        ev.Description = dto.Description; ev.EventType = dto.EventType;
        await db.SaveChangesAsync();
        return Ok(ev.ToSummary());
    }

    /// <summary>Organiser only: deletes an event owned by the logged-in organiser, with its categories, routes, enrolments and results.</summary>
    /// <response code="200">Confirmation message.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event not found.</response>
    [HttpDelete("{id:int}"), Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(ApiError), 200)]
    [ProducesResponseType(403)]
    [ProducesResponseType(typeof(ApiError), 404)]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await db.Events.FirstOrDefaultAsync(e => e.EventID == id);
        if (ev == null) return NotFound(new ApiError("Event not found."));
        if (ev.OrganiserID != User.GetUserId()) return Forbid();

        var categoryIds = await db.Categories.Where(c => c.EventID == id).Select(c => c.CategoryID).ToListAsync();
        await db.RemoveCategoriesCascadeAsync(categoryIds);
        db.Events.Remove(ev);
        await db.SaveChangesAsync();
        return Ok(new ApiError("Event deleted."));
    }
}
