using System.Globalization;
using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Api.Services;

public interface IWeatherService
{
    /// <summary>Returns a 7-day forecast for the location, or null if the location can't be found.</summary>
    Task<WeatherDto?> GetForecastAsync(string location, CancellationToken ct = default);
}

/// <summary>Uses the free Open-Meteo geocoding + forecast APIs (no API key needed).</summary>
public class WeatherService(HttpClient http) : IWeatherService
{
    public async Task<WeatherDto?> GetForecastAsync(string location, CancellationToken ct = default)
    {
        var name = location.Split(',')[0].Trim();
        var geo = await http.GetFromJsonAsync<JsonElement>(
            $"https://geocoding-api.open-meteo.com/v1/search?name={Uri.EscapeDataString(name)}&count=1", ct);
        if (!geo.TryGetProperty("results", out var results) || results.GetArrayLength() == 0) return null;

        var first = results[0];
        var lat = first.GetProperty("latitude").GetDouble();
        var lon = first.GetProperty("longitude").GetDouble();
        var url = "https://api.open-meteo.com/v1/forecast" +
                  $"?latitude={lat.ToString(CultureInfo.InvariantCulture)}&longitude={lon.ToString(CultureInfo.InvariantCulture)}" +
                  "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=7";
        var forecast = await http.GetFromJsonAsync<JsonElement>(url, ct);
        var daily = forecast.GetProperty("daily");
        var dates = daily.GetProperty("time");
        var max = daily.GetProperty("temperature_2m_max");
        var min = daily.GetProperty("temperature_2m_min");
        var rain = daily.GetProperty("precipitation_probability_max");

        var days = new List<WeatherDayDto>();
        for (var i = 0; i < dates.GetArrayLength(); i++)
            days.Add(new WeatherDayDto(dates[i].GetString()!, Num(max, i), Num(min, i), (int?)Num(rain, i)));

        return new WeatherDto(name, lat, lon, days);
    }

    private static double? Num(JsonElement arr, int i) =>
        arr[i].ValueKind == JsonValueKind.Number ? arr[i].GetDouble() : null;
}
