using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.Api.Models;

public static class Roles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
    public const string Admin = "Admin";
}

public static class EnrolmentStatus
{
    public const string Pending = "Pending";
    public const string Confirmed = "Confirmed";
    public const string Cancelled = "Cancelled";
}

public class User
{
    [Key] public int UserID { get; set; }
    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [Required, MaxLength(150)] public string Email { get; set; } = "";
    [Required, MaxLength(255)] public string PasswordHash { get; set; } = "";
    [Required, MaxLength(20)] public string Role { get; set; } = Roles.Participant;
    [MaxLength(20)] public string? PhoneNumber { get; set; }
    public DateTime DateRegistered { get; set; } = DateTime.Now;

    public ICollection<Event> OrganisedEvents { get; set; } = new List<Event>();
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

public class Event
{
    [Key] public int EventID { get; set; }
    public int OrganiserID { get; set; }
    [Required, MaxLength(150)] public string EventName { get; set; } = "";
    [Column(TypeName = "date")] public DateTime EventDate { get; set; }
    [Required, MaxLength(150)] public string Location { get; set; } = "";
    public string? Description { get; set; }
    [Required, MaxLength(20)] public string EventType { get; set; } = "Running";
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public User Organiser { get; set; } = null!;
    public ICollection<Category> Categories { get; set; } = new List<Category>();
}

public class Category
{
    [Key] public int CategoryID { get; set; }
    public int EventID { get; set; }
    [Required, MaxLength(50)] public string CategoryName { get; set; } = "";
    [Column(TypeName = "decimal(5,2)")] public decimal Distance { get; set; }
    [Column(TypeName = "decimal(8,2)")] public decimal EntryFee { get; set; }
    public int MaxParticipants { get; set; } = 500;

    public Event Event { get; set; } = null!;
    public RaceRoute? Route { get; set; }
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

/// <summary>Maps to the "Routes" table (named RaceRoute to avoid clashing with [Route]).</summary>
public class RaceRoute
{
    [Key] public int RouteID { get; set; }
    public int CategoryID { get; set; }
    [MaxLength(100)] public string? RouteName { get; set; }
    [Required, MaxLength(150)] public string StartPoint { get; set; } = "";
    [Required, MaxLength(150)] public string EndPoint { get; set; } = "";
    public int? ElevationGain { get; set; } = 0;
    [MaxLength(255)] public string? MapURL { get; set; }

    public Category Category { get; set; } = null!;
}

public class Enrolment
{
    [Key] public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public int CategoryID { get; set; }
    public DateTime EnrolmentDate { get; set; } = DateTime.Now;
    [Required, MaxLength(20)] public string Status { get; set; } = EnrolmentStatus.Confirmed;

    public User Participant { get; set; } = null!;
    public Category Category { get; set; } = null!;
    public Result? Result { get; set; }
}

public class Result
{
    [Key] public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public TimeSpan? FinishTime { get; set; }
    public int? Position { get; set; }
    [Required, MaxLength(20)] public string Status { get; set; } = "Finished";

    public Enrolment Enrolment { get; set; } = null!;
}
